public class HelloWorld
{
  public static void Main()
  {
    System.Console.WriteLine("Hello World!");
    System.Console.ReadLine();
  }
}